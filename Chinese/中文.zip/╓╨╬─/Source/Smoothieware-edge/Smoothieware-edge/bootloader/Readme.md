This is only needed if you have an old Beta board, or need to reflash the bootloader.
All Smoothie baords come pre flashed with the current bootloader.

see http://smoothieware.org/flashing-the-bootloader for details on how to flash the bootloader if you need to.
